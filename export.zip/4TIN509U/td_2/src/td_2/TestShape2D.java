package td_2;

public class TestShape2D {
	public static void main(String[] args) {
        Point2D  p1 = new Point2D(1, 2);
        p1.print();
        p1.translate(5);
        p1.print();
        
        Shape2D s = new Point2D(1, 2);
        s.print();

        Point2D A = new Point2D(0, 0);
        Point2D B = new Point2D(5, 0);
        Point2D C = new Point2D(0, 5);
        s = new Triangle(A, B, C);
        s.print();   
        
        Shape2D[] tab = Shape2D.createTab();
        for(int i=0;i<tab.length;i++) {
        	tab[i].print();
        }
        String name = "TestShape";
        System.out.println(name);
        
        Point2D D = new Point2D(1.0, 1.0);
        Point2D E = new Point2D(1.0, 1.0);
        D.equals(E);
    }
}
