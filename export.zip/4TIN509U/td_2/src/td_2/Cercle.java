package td_2;
import java.lang.Math;

class Cercle extends Shape2D{
	private Point2D center;
	private double ray;

	public Point2D getCenter() {
		return center;
	}

	public void setCenter(Point2D center) {
		this.center = center;
	}

	public double getRay() {
		return ray;
	}

	public void setRay(double ray) {
		this.ray = ray;
	}


	Cercle (Point2D center, double ray) {
		this.center = center;
		this.ray = ray;
	}

	double surface() {
		return Math.PI * ray*ray;
	}
	
	public double perimeter() {
		return 2*Math.PI * ray;
	}
	
	public void translate(double dx, double dy) {
		double x = center.getX();
		double y = center.getY();
		x += dx;
		y += dy;
		center.setX(x);
		center.setY(y);
	}

	public void translate(double delta) {
		translate(delta, delta);
	}

	boolean isInside(Point2D p) {
		double distance = p.distance(center);
		return distance <= ray;
	}

	@Override
	public double area() {
		return Math.PI * ray*ray;
	}
}