package td_2;

public class AxesLignedRectangle extends Shape2D{
	Point2D s1;
    Point2D s2;
    Point2D s3;
    Point2D s4;
    
    
	
    AxesLignedRectangle (Point2D s1, Point2D s2, Point2D s3, Point2D s4){
    	this.s1 = s1;
    	this.s2 = s2;
    	this.s3 = s3;
    	this.s4 = s4;
    }
    
	static double area(Point2D s1, Point2D s2, Point2D s3, Point2D s4) {
    	double p1 = s1.distance(s2);
    	double p2 = s1.distance(s3);
    	
    	return p1*p2;
    }
	
	@Override
	public double area() {
		double p1 = s1.distance(s2);
		double p2 = s1.distance(s3);
		
		return p1*p2;
	}

	
	static double perimeter(Point2D s1, Point2D s2, Point2D s3, Point2D s4) {
		double p1 = s1.distance(s2);
    	double p2 = s1.distance(s3);
    	
    	return p1*2+p2*2;
	}
	
	public void translate(double dx, double dy) {
		double x1 = s1.getX();
		double y1 = s1.getY();
		x1 += dx;
		y1 += dy;
		s1.setX(x1);
		s1.setY(y1);
		
		double x2 = s2.getX();
		double y2 = s2.getY();
		x2 += dx;
		y2 += dy;
		s2.setX(x2);
		s2.setY(y2);
		
		double x3 = s3.getX();
		double y3 = s3.getY();
		x3 += dx;
		y3 += dy;
		s3.setX(x3);
		s3.setY(y3);
		
		double x4 = s4.getX();
		double y4 = s4.getY();
		x4 += dx;
		y4 += dy;
		s4.setX(x4);
		s4.setY(y4);
	}

	public void translate(double delta) {
		translate(delta, delta);
	}

	@Override
	public double perimeter() {
		double p1 = s1.distance(s2);
    	double p2 = s1.distance(s3);
    	
    	return p1*2+p2*2;
	}
}
