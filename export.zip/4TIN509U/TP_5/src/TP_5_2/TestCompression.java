package TP_5_2;


public class TestCompression {
	public static void main(String[] args) {
		ICompression zipper = new BasicRLECompression() ;
		
		try {
			
			String c = zipper.compress("aa##acb#aaaaa");
			System.out.println("Compression : " + c);
		
			String result = zipper.uncompress("aa#04ba##4bb#0d");
			System.out.println("Decompression : " + result);
		} 
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
