package TP_5_2;

public class CompressException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1799400843423576176L;

	String decoded;
	String remaining;
	String message;
	
	public CompressException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CompressException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	public String getDecoded() {
		return decoded;
	}
	
	public String getMesssage() {
		return message;
	}

	public String getRemaining() {
		return remaining;
	}
}
