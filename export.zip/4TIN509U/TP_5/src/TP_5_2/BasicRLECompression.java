package TP_5_2;

public  class BasicRLECompression implements ICompression {
	//public static void main(String[] args) {
	char flag = '#';
	
	int lengthOfSingleLetterPrefix(String s) {
		char c = s.charAt(0);
		
		int i;
		
		for(i = 1; i < s.length(); i++) {
			if(s.charAt(i) != c) {
				if(i == 1) {
					return 1;
				}
				else {
					return i;
				}
			} 
		}
		return i;
	}
	
	public String compress(String data){
		String result = new String("");
		while(data.isEmpty() == false) {

			char c = data.charAt(0);
			
			if(data.charAt(0) == flag) {
				result = result.concat(String.valueOf(c) + "0");
				data = data.substring(1,data.length());
			}
			else {
				int t = lengthOfSingleLetterPrefix(data);		
			
				int save = t;
			
				while(t > 9) {
				
				result = result.concat(String.valueOf(c) + String.valueOf(flag)+ "9");
				t = t - 9;		
				}
			
				if(t < 4 ) {
					for(int i= 0; i < t; i++) {
						result = result.concat(String.valueOf(c));
					}
				}else {
					result = result.concat(String.valueOf(c) + String.valueOf(flag) + Integer.toString(t));
				}
				data = data.substring(save,data.length());	
			}
		}
			
		return result;
				
	}
	
    public String uncompress(String data) throws CompressException {
    	String result = new String("");    	
	    	
	    	while(data.isEmpty() == false) {
	    		int i = 0;
	    		if(data.charAt(0) != flag ) {
	    			if(data.length() == 1) {
	    				result = result.concat(String.valueOf(data.charAt(0)));
	    				i=1;
	    			}
	    			while(data.length() > i && data.charAt(0) == data.charAt(i) ) {
		    			result = result.concat(String.valueOf(data.charAt(0)));
		    			i++;
		    			if(i == 3) {
		    				data = data.substring(i,data.length());
		    				throw new CompressException("erreur : " + data.substring(0, i) + "\ncode attendu, par exemple : aaa\ndécodé : "+ result + "\nnon décodé : " + data + "\n");
		    			}
	    			}
	    			System.out.println("aaa i : " + i + "| result : " + result + "\n");
	    			
	    		}
	    		if(data.charAt(0) == flag) {
	    			if(data.charAt(1) != '0') {
	    				throw new CompressException("erreur : " + data.substring(0, 1) + "\ncode attendu, par exemple : #0\ndécodé : "+ result + "\nnon décodé : " + data + "\n");
	    			}else {
	    				result = result.concat(String.valueOf(flag));
	    				i=2;
		    			System.out.println("#0 i : " + i + "| result : " + result + "\n");
	    			}
	    			
	    		}
	    		if(data.length() > 1 && data.charAt(0) != flag && data.charAt(1) == flag && data.charAt(2) != '0' && data.charAt(2) != flag) {
	    			for(int x = 0; x < Character.getNumericValue(data.charAt(2)); x++) {
	    				result = result.concat(String.valueOf(data.charAt(0)));
	    			}
	    			i=3;
	    			System.out.println("a#4 i : " + i + "| result : " + result + "\n");
	    		}
	    		data = data.substring(i,data.length());
	    		System.out.println("data : " + data + " | l : " + data.length() + "\n");
			}			
		
		return result;
    }

}
