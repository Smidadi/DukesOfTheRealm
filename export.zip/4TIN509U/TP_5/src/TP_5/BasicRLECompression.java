package TP_5;

public  class BasicRLECompression implements ICompression {
	//public static void main(String[] args) {
	char flag = '#';
	
	int lengthOfSingleLetterPrefix(String s) {
		char c = s.charAt(0);
		
		int i;
		
		for(i = 1; i < s.length(); i++) {
			if(s.charAt(i) != c) {
				if(i == 1) {
					return 1;
				}
				else {
					return i;
				}
			} 
		}
		return i;
	}
	
	public String compress(String data) throws CompressException {
		String result = new String("");
		while(data.isEmpty() == false) {

			char c = data.charAt(0);
			
			if(data.charAt(0) == flag) {
				throw new CompressException("élément déjà compressé : " + result + "\n" + "erreur rencontré : le caractère correspond au flag \nélément restant à compresser : " + data + "\n");
			}
			
			int t = lengthOfSingleLetterPrefix(data);		
			
			int save = t;

			while(t > 9) {
				
				result = result.concat(String.valueOf(c) + String.valueOf(flag)+ "9");
				t = t - 9;		
			}

			result = result.concat(String.valueOf(c) + String.valueOf(flag) + Integer.toString(t));
			
			data = data.substring(save,data.length());			
		}
			
		return result;
				
	}
	
    public String uncompress(String data) throws CompressException {
    	String result = new String("");
    	
    
	    	if(data.length()%3 != 0 ) {
	    		throw new CompressException("le code ne peut être décompresser, il comporte des erreurs");
	    	}
	    	
	    	while(data.isEmpty() == false) {								
				if(data.charAt(0) == flag || data.charAt(1) != flag || data.charAt(2) == flag) {
					throw new CompressException("structure du code éronnée, ex : caractère = flag ou flag incorrect\nélément déja décompressé : " + result + "\nélément restant à décompresser : " + data);
				}
				for(int i = 0; i < Character.getNumericValue(data.charAt(2)); i++) {
					result = result.concat(String.valueOf(data.charAt(0)));
				}
				data = data.substring(3,data.length());
			}			
		
		return result;
    }

}
