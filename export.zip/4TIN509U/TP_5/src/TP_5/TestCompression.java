package TP_5;


public class TestCompression {
	public static void main(String[] args) {
		ICompression zipper = new BasicRLECompression() ;
		
		try {
			
			String c = zipper.compress("aaaabccc");
			System.out.println("Compression : " + c);
		
			String result = zipper.uncompress("a#4b#1c#3");
			System.out.println("Decompression : " + result);
		} 
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
