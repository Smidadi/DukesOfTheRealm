package TP_5;

public class CompressException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1799400843423576176L;

	public CompressException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CompressException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
