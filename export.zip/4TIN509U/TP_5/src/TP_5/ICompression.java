package TP_5;

public interface ICompression {
	public String compress(String data) throws CompressException;
    public String uncompress(String data) throws CompressException;
}
