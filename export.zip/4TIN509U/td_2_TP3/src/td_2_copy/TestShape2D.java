package td_2;

public class TestShape2D {
	public static void main(String[] args) {
        Point2D  p1 = new Point2D(1, 2);
        p1.print();
        p1.translate(5);
        p1.print();        
    }

}
