package td_2;

public class AxesAlignedRectangle {
	public static void main(String[] args) {
		Point2D s1 = new Point2D(0,0);
	    Point2D s2 = new Point2D(0,2);
	    Point2D s3 = new Point2D(4,0);
	    Point2D s4 = new Point2D(4,2);
	    
	    double s = Rectangle.surface(s1,s2,s3,s4);
	    System.out.println("Surface : " + s);
	    
	    double p = Rectangle.perimeter(s1,s2,s3,s4);
	    System.out.println("Perimètre : " + p);
	    
	    Rectangle r = new Rectangle(s1,s2,s3,s4);
	    r.movement(2,2);
	}
}
