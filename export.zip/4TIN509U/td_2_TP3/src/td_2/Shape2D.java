package td_2;
import java.lang.Math;

public class Shape2D {
	public double area() {
		return 0;
    }
    
    public double perimeter() {
        return 0;
    }
    
    public void translate(double dx, double dy) { }

    public void translate(double delta) {
        translate(delta, delta);
    }

    public void print() {
        System.out.println("Shape2D");
    } 
    
    public static Shape2D[] createTab(){ //0circle 1triangle 2carre 3rectangle
    	Shape2D tab[] = new Shape2D[10];
    	for(int i=0; i<10; i++) {
    		int rand = (int) (Math.random()*4); 
    		switch(rand) {
    		case 0:
    			Point2D center = new Point2D((double) (Math.random())*10,(double) (Math.random())*10);
    			double ray = (double) (Math.random())*10;
    			Cercle c = new Cercle(center,ray);
    			tab[i]=c;
    			break;
    		case 1:
    			Point2D t1 = new Point2D((double) (Math.random()*10),(double) (Math.random()*10));
    			Point2D t2 = new Point2D((double) (Math.random()*10),(double) (Math.random()*10));
    			Point2D t3 = new Point2D((double) (Math.random()*10),(double) (Math.random()*10));
    			Triangle t = new Triangle (t1,t2,t3);
    			tab[i]=t;
    			break;
    		case 2:
    			double x = (double) (Math.random()*10);
    			double x2 = (double) (Math.random()*10);
    			double y = (double) (Math.random()*10);
    			double d = x - x2;
    			double y2 = y + d;
    			Point2D s1 = new Point2D(x,y);
    			Point2D s2 = new Point2D(x2,y);
    			Point2D s3 = new Point2D(x2,y2);
    			Point2D s4 = new Point2D(x,y2);
    			AxesAlignedSquare s = new AxesAlignedSquare(s1,s2,s3,s4);
    			tab[i]=s;
    			break;
    		case 3:
    			double xr = (double) (Math.random()*10);
    			double xr2 = (double) (Math.random()*10);
    			double yr = (double) (Math.random()*10);
    			double yr2 = (double) (Math.random()*10);
    			Point2D r1 = new Point2D(xr,yr);
    			Point2D r2 = new Point2D(xr2,yr);
    			Point2D r3 = new Point2D(xr2,yr2);
    			Point2D r4 = new Point2D(xr,yr2);
    			AxesLignedRectangle r = new AxesLignedRectangle(r1,r2,r3,r4);
    			tab[i]=r;
    			break;
    		}
    	}
        return tab;
    }
}

