package td_2;

class TestTriangle {
    public static void main(String[] args) {

        Point2D s1 = new Point2D(0,0);
        Point2D s2 = new Point2D(0,4);
        Point2D s3 = new Point2D(2,0);

        double perim = Triangle.perimeter(s1,s2,s3);
        System.out.println(perim);

        boolean isocele = Triangle.isocele(s1,s2,s3);
        System.out.println(isocele);
        
        double surface = Triangle.area(s1,s2,s3);
        System.out.println(surface);
        
        Triangle t = new Triangle(s1,s2,s3); 
        
        t.translate(2,2);
        
    }
}