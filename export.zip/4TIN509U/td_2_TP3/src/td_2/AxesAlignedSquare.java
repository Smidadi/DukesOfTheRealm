package td_2;

public class AxesAlignedSquare extends AxesLignedRectangle{
	AxesAlignedSquare(Point2D s1, Point2D s2, Point2D s3, Point2D s4) {
		super(s1, s2, s3, s4);
	}

}
