package td_2;


class TestCercle {
	public static void main(String[] args) throws CloneNotSupportedException {
		//Point2D  p = new Point2D(2,3);
		//Point2D  center = new Point2D(1,1);
		//Point2D centerClone = Point2D.clone(center);
		//Cercle c = new Cercle(centerClone, 4);
		//center.setX(12); // Change la position du centre du cercle
		
		//System.out.println(c.getCenter()+"<->"+center);
		//System.out.println("Surface = " + c.surface());
		//System.out.println("Perimètre = " + c.perimeter());
		//System.out.println("Interieur : " + c.isInside(p));
		
		//centerClone.translate(2);
	}
}
