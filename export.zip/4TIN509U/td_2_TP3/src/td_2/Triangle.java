package td_2;
import java.lang.Math;

class Triangle extends Shape2D{
	Point2D s1;
    Point2D s2;
    Point2D s3;
	
    Triangle (Point2D s1, Point2D s2, Point2D s3){
    	this.s1 = s1;
    	this.s2 = s2;
    	this.s3 = s3;
    }
    
    static double perimeter(Point2D s1, Point2D s2, Point2D s3){
        double dist1 = s1.distance(s2); 
        double dist2 = s2.distance(s3); 
        double dist3 = s3.distance(s1); 
        return dist1+dist2+dist3;
    }

    static boolean isocele(Point2D s1, Point2D s2, Point2D s3){
        double dist1 = s1.distance(s2); 
        double dist2 = s2.distance(s3); 
        double dist3 = s3.distance(s1); 
        if(dist1 == dist2 || dist2 == dist3 || dist3 == dist1){
            return true;
        }
        return false;
    }
    
    static double area(Point2D s1, Point2D s2, Point2D s3) {
    	double p1 = s1.distance(s2);
    	double p2 = s2.distance(s3);
    	double p3 = s3.distance(s1);
    	
    	double p = (p1 + p2 + p3)/2;
    	double s = Math.sqrt(p*(p-p1)*(p-p2)*(p-p3));
    	return s;
    }
    
    public void translate(double dx, double dy) {
		double x1 = s1.getX();
		double y1 = s1.getY();
		x1 += dx;
		y1 += dy;
		s1.setX(x1);
		s1.setY(y1);
		
		double x2 = s2.getX();
		double y2 = s2.getY();
		x2 += dx;
		y2 += dy;
		s2.setX(x2);
		s2.setY(y2);
		
		double x3 = s3.getX();
		double y3 = s3.getY();
		x3 += dx;
		y3 += dy;
		s3.setX(x3);
		s3.setY(y3);
	}

    public void print() {
        System.out.println("Triangle " + s1 +", "+ s2 +", "+ s3);
    }
    
    
    
	public void translate(double delta) {
		translate(delta, delta);
	}
}
